package pcc.analysis;

public enum ChangeType{
	ADDED, REMOVED, CHANGED;
}
