package pcc.test.integration;
import pcc.vercon.Project;
import pcc.vercon.ProjectVersion;


public class IOUtilsStub{

/*	
	private static Project proj = new StubProject();
	public static Project openProject(String filename){
		if(filename.equals("proj/project.dat"))
			return proj;
		throw new RuntimeException("Invalid proj name");
	}

	public static void saveProject(Project project, String filename){
		//TODO
	}
	public static ProjectVersion openVersion(String filename){
		//TODO
		return null;
	}
	public static void saveVersion(Project project, String filename){
		//TODO
	}
	public static String[] openSourceFile(String filename){
		//TODO
		return null;
	}
	public static void writeSourceFile(String filename, String contents){
		System.out.println("Writing: "+filename);
		System.out.println("################");
		System.out.println(contents);
		System.out.println("################");
	}
	public static void createFolder(String name){
		System.out.println("MkDir: " + name);
	}
//*/
}
