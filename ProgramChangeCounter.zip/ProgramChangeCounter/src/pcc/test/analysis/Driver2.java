package pcc.test.analysis;

import pcc.analysis.StringDistanceUtil;

public class Driver2 {
	public static void main(String[] args){
		System.out.println(StringDistanceUtil.getDiff("Helasdlkfj.", "hello."));
	}
}
